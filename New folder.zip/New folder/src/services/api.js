// ----------------------------This is public(network) ip address api function--------------------------------
import axios from "axios";

const BASE_URL = import.meta.env.VITE_API_BASE_URL || "https://newschoolprojectapi.schoolsoftwaresolution.in";
const API_URL = BASE_URL + "/MobApi.asmx/MobileApi";
const AUTH_KEY = "SYS101";

export const getlogin = async (name, pass) => {
  // Step 1 — Get Public IP
  let publicIp = "";
  try {
    const ipResponse = await axios.get("https://api.ipify.org?format=json");
    publicIp = ipResponse.data.ip; // <-- Public IP here
  } catch (err) {
    console.error("IP Fetch Error:", err);
    publicIp = "0.0.0.0"; // fallback
  }

  const params = {
    ParmCriteria: JSON.stringify({
        UserName: String(name), Password: String(pass), DeviceName: "", DeviceIP: publicIp, 
        ApiAdd: "SoftwareLogin", CallBy: "MobileApi", AuthKey:"SYS101"
    }),
    ApiAdd: "SoftwareLogin",
  };
  console.log("id",publicIp);

  const response = await axios.get(API_URL, { params });
  return response.data;
};
// ----------------------------This is public(network) ip address api function end------------------------------



// ------------------------------------This is institute List api function --------------------------------------
export const getinstitute = async () => {
    const params = {
        ParmCriteria: JSON.stringify({
            ApiAdd: "InstituteList", 
            CallBy: "MobileApi",
            AuthKey: AUTH_KEY,
        }),
        ApiAdd: "InstituteList",
    };
    const response = await axios.get(API_URL, { params });
    return response.data;
};
// ----------------------------------This is institute List api function end--------------------------------------



// ------------------------------------This is Session List api function --------------------------------------
export const getsession = async () => {
    const params = {
        ParmCriteria: JSON.stringify({
            ApiAdd: "SessionList",
            CallBy: "MobileApi",
            AuthKey: AUTH_KEY,
        }),
        ApiAdd: "SessionList",
    };
    const response = await axios.get(API_URL, { params });
    return response.data;
};
// ----------------------------------This is Session List api function end--------------------------------------



// --------------------------------------This is class List api function -----------------------------------------
export const getclass = async (insid) => {
    const params = {
        ParmCriteria: JSON.stringify({
            InstId: insid,
            ApiAdd: "ClassList",
            CallBy: "MobileApi",
            AuthKey: AUTH_KEY,
        }),
        ApiAdd: "ClassList",
    };
    const response = await axios.get(API_URL, { params });
    return response.data;
};
// ------------------------------------This is class List api function end----------------------------------------



// --------------------------------------This is Enquiry Report api function -----------------------------------------
export const getEnquiry = async (instid, sesid, clid) => {
    const params = {
        ParmCriteria: JSON.stringify({
            InstId: instid,
            SessionId: sesid,
            ClassId: clid,
            ApiAdd: "EnquireStudentList",
            CallBy: "MobileApi",
            AuthKey: AUTH_KEY,
        }),
        ApiAdd: "EnquireStudentList",
        
    };
    const response = await axios.get(API_URL, { params });
    return response.data;
};
// ------------------------------------This is Enquiry Report api function end----------------------------------------



// --------------------------------------This is Enquiry Insert api function -----------------------------------------
export const getEnquiryInsert = async (data) => {
  const params = {
    ParmCriteria: JSON.stringify({
        InstId: data.instId, SessionId: data.sessId, UserId: data.userId, EqId: data.eqid, ClassId: data.classId, 
        EqNo: data.eqno, EqDate: data.enqDate, FFees: data.ffees, Name: data.name, Gender: data.gender, Dob: data.dob, 
        CastId: data.casteId, FName: data.father, FOcc: data.fatherOcc, FMob: data.fatherMobile, MName: data.mother, 
        MOcc: data.motherOcc, MMob: data.motherMobile, GName: data.guardian, GOcc: data.guardianOcc, GMob: data.guardianMobile, 
        GRel: data.guardianRel, PhNo: data.phone, BPlace: data.birthplace, BGroup: data.bloodgroup, BSing: data.bodysign, 
        Add1: data.address, Add2: data.address2, Rem: data.remark, LastSch: data.lastschool, LClassId: data.lastclass, Per: data.percent, 
        ApiAdd: "EnquireInsertUpdate", 
        CallBy: "MobileApi",
        AuthKey: "SYS101", 
    }),
    ApiAdd: "EnquireInsertUpdate",
  };

  const response = await axios.get(API_URL, { params });
  return response.data;
};
// ------------------------------------This is Enquiry Insert api function end----------------------------------------


// --------------------------------------This is Enquiry Details api function -----------------------------------------
export const getEnquiryDetail = async (eqid) => {
    const params = {
        ParmCriteria: JSON.stringify({ 
            EqId: eqid,
            ApiAdd: "EnquireDetails", 
            CallBy: "MobileApi",
            AuthKey: AUTH_KEY,
        }),
        ApiAdd: "EnquireDetails",
    };
    const response = await axios.get(API_URL, { params });
    return response.data;
};
// ------------------------------------This is Enquiry Details api function end----------------------------------------



// --------------------------------------This is Caste List api function -----------------------------------------
export const getcaste = async () => {
    const params = {
        ParmCriteria: JSON.stringify({          
            ApiAdd: "CasteList", 
            CallBy: "MobileApi",
            AuthKey: AUTH_KEY,
        }),
        ApiAdd: "CasteList",
    };
    const response = await axios.get(API_URL, { params });
    return response.data;
};
// ------------------------------------This is Caste List api function end----------------------------------------



// --------------------------------------This is Caste List api function -----------------------------------------
export const getEnquiryNo = async (insid) => {
    const params = {
        ParmCriteria: JSON.stringify({ 
            InstId: insid,
            ApiAdd: "GetEnquireNo", 
            CallBy: "MobileApi",
            AuthKey: AUTH_KEY,
        }),
        ApiAdd: "GetEnquireNo",
    };
    const response = await axios.get(API_URL, { params });
    return response.data;
};
// ------------------------------------This is Caste List api function end----------------------------------------



// --------------------------------------This is Student List api function -----------------------------------------
export const getStudentList = async (instid, sesid, clid) => {
    const params = {
        ParmCriteria: JSON.stringify({
            InstId: instid,
            SessionId: sesid,
            ClassId: clid,
            ApiAdd: "StudentList",
            CallBy: "MobileApi",
            AuthKey: AUTH_KEY,
        }),
        ApiAdd: "StudentList",
        
    };
    const response = await axios.get(API_URL, { params });
    return response.data;
};
// ------------------------------------This is Student List api function end----------------------------------------



// --------------------------------------This is Type List api function -----------------------------------------
export const getTypeList = async () => {
    const params = {
        ParmCriteria: JSON.stringify({
            ApiAdd: "TypeList",
            CallBy: "MobileApi",
            AuthKey: AUTH_KEY,
        }),
        ApiAdd: "TypeList",
        
    };
    const response = await axios.get(API_URL, { params });
    return response.data;
};
// ------------------------------------This is Type List api function end----------------------------------------



// --------------------------------------This is Serial No api function -----------------------------------------
export const getSerialNo = async (instid) => {
    const params = {
        ParmCriteria: JSON.stringify({
            InstId: instid,
            ApiAdd: "GetStudentMaxSrNo",
            CallBy: "MobileApi",
            AuthKey: AUTH_KEY,
        }),
        ApiAdd: "GetStudentMaxSrNo",
        
    };
    const response = await axios.get(API_URL, { params });
    return response.data;
};
// ------------------------------------This is Serial No api function end----------------------------------------



// --------------------------------------This is Student Insert api function -----------------------------------------
export const getCreateStudent = async (data) => { 
    const params = { 
        ParmCriteria: JSON.stringify({ 
            InstId: data.instId, SessionId: data.sessId, EqNo: data.eqno, UserId: data.userId, StId: data.studId, OldSrNo: data.srno, 
            EnroNo: data.enroNo, Name: data.name, Gender: data.gen, Dob: data.dob, SType: data.studtype, CastId: data.casteId, 
            Caste: data.caste, AddDate: data.addDate, JDate: data.joinDate, FCalDate: data.feeCalDate, LastSch: data.lstSchl, 
            LClassId: data.lstclId, ClassId: data.clid, TcNo: data.tcNo, TcDate: data.tcDate, LPSess: data.lstsess, IsNew: data.isNew, 
            Nation: data.nation, FName: data.fName, FOcc: data.fOcc, FMob: data.fNum, MName: data.mNane, MOcc: data.mOcc, MMob: data.mNum, 
            FAaNo: data.fAadhar, MAaNo: data.mAadhar, JAaNo: data.jAadhar, GName: data.guardian, GOcc: data.guardianOcc, GMob: data.guardianNum, 
            GRel: data.guardianRel, PhNo: data.phone, FInc: data.fatherInc, BPlace: data.birthplace, BGroup: data.bloodgroup, 
            BSing: data.bodysign, Pen: data.panNum, AppId: data.ApparId, Add1: data.address, Add2: data.address2, Email: data.mail, 
            AaNo: data.aadharNo, LBala: data.lastBal, TLBala: data.translastbal, FDis: data.feeDis, AddFee: data.addFee, 
            QMoney: data.quesMoney, Rem: data.remark, Leave: data.left, NSODate: data.NsoDate, LReason: data.leaveRes, 
        
            ApiAdd: "StudentInsertUpdate", 
            CallBy: "MobileApi", 
            AuthKey: "SYS101", 
        }), 
        ApiAdd: "StudentInsertUpdate", 
    };
    
    const response = await axios.get(API_URL, { params });
    return response.data;
};

// ------------------------------------This is Student Insert api function end----------------------------------------



// --------------------------------------This is Serial No api function -----------------------------------------
export const getEnquiryNoDetails = async (eqno) => {
    const params = {
        ParmCriteria: JSON.stringify({
            EqNo: eqno,
            ApiAdd: "EnquireNoDetails",
            CallBy: "MobileApi",
            AuthKey: AUTH_KEY,
        }),
        ApiAdd: "EnquireNoDetails",
        
    };
    const response = await axios.get(API_URL, { params });
    return response.data;
};
// ------------------------------------This is Serial No api function end----------------------------------------



// --------------------------------------This is Student Details api function -----------------------------------------
export const getStudentDetails = async (insid, studid, sessid, clid) => {
    const params = {
        ParmCriteria: JSON.stringify({
            InstId: insid, 
            StId: studid, 
            SessionId: sessid, 
            ClassId: clid, 
            ApiAdd: "StudentDetails",
            CallBy: "MobileApi",
            AuthKey: AUTH_KEY,
        }),
        ApiAdd: "StudentDetails",
        
    };
    const response = await axios.get(API_URL, { params });
    return response.data;
};
// ------------------------------------This is Student Details api function end----------------------------------------



// --------------------------------------This is Sibling Details api function -----------------------------------------
export const getSiblingDetails = async (insid, studid, sessid ) => {
    const params = {
        ParmCriteria: JSON.stringify({
            InstId: insid, 
            StId: studid, 
            SessionId: sessid, 
            ApiAdd: "SiblingDetails",
            CallBy: "MobileApi",
            AuthKey: AUTH_KEY,
        }),
        ApiAdd: "SiblingDetails",
        
    };
    const response = await axios.get(API_URL, { params });
    return response.data;
};
// ------------------------------------This is Sibling Details api function end----------------------------------------



// --------------------------------------This is Exam List api function -----------------------------------------
export const getexam = async (insid) => {
    const params = {
        ParmCriteria: JSON.stringify({
            InstId: insid,
            ApiAdd: "ExamList", 
            CallBy: "MobileApi",
            AuthKey: "AK101"
        }),
        SchID: scId,
        ApiAdd: "ExamList",
    };
    const response = await axios.get(API_URL, { params });
    return response.data;
};
// ------------------------------------This is Exam List api function end----------------------------------------



// --------------------------------------This is Exam Type List api function -----------------------------------------
export const getsubexam = async (insid) => {
    const params = {
        ParmCriteria: JSON.stringify({
            InstId: insid,
            ApiAdd: "ExamTypeList", 
            CallBy: "MobileApi",
            AuthKey: "AK101"
        }),
        SchID: scId,
        ApiAdd: "ExamTypeList",
    };
    const response = await axios.get(API_URL, { params });
    return response.data;
};
// ------------------------------------This is Exam Type List api function end----------------------------------------



// --------------------------------------This is Sub Exam Subject List api function -----------------------------------------
export const getsubject = async (insid, clid, exmid, subexmid) => {
    const params = {
        ParmCriteria: JSON.stringify({
            InstId: insid,
            ClassId: clid, 
            ExamId: exmid,
            SubExamId: subexmid,
            ApiAdd: "SubExamSubjectList", 
            CallBy: "MobileApi",
            AuthKey: "AK101"
        }),
        SchID: scId,
        ApiAdd: "SubExamSubjectList",
    };
    const response = await axios.get(API_URL, { params });
    return response.data;
};
// ------------------------------------This is Sub Exam Subject List api function end----------------------------------------




// --------------------------------------This is Bank List api function -----------------------------------------
export const getbank = async (insid,) => {
    const params = {
        ParmCriteria: JSON.stringify({
            InstId: insid,
            ApiAdd: "BankList",
            CallBy:"MobileApi",
            "AuthKey": AUTH_KEY
        }),
        ApiAdd: "BankList",
    };
    const response = await axios.get(API_URL, { params });
    return response.data;
};
// ------------------------------------This is Bank List api function end----------------------------------------