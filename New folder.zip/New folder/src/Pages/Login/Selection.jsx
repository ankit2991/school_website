// import React from "react";
// import { useNavigate } from "react-router-dom";
// import Options from "../../Components/Page_Forms/Options";

// function Selection() {
//   const navigate = useNavigate();
//   const handlelogin = () => {
//     navigate("/Home");
//   };
//   const website = () => {
//     window.open("https://systranstechnology.com/", "_blank");
//   };

//   return (
//     <div className="min-h-screen w-full flex items-center justify-center bg-cover bg-no-repeat bg-[url(/background_poster2.png)]">
//         <div className=" w-full mx-3 md:w-1/2 rounded-4xl bg-gradient-to-b from-[#E46343] via-[#CC3015] to-[#772109] p-8 flex flex-col justify-center">
//             {/* Show Logo only on small screens */}
//             <div className="flex items-center gap-3  mb-6 ">
//               <img src="/Systrans_Logo.jpeg" alt="School Logo" className="h-15 w-15 object-cover rounded-full border-2 border-white flex-shrink-0" />
//               <h1 className="cursor-default text-2xl font-[600] text-white">SysTrans</h1>
//             </div>
//             {/* Login Form */}
//             <h2 className="text-4xl font-bold text-white mb-6 text-center md:text-left"> Set Session </h2>
//             <div className="flex flex-col gap-4">
//               <Options label={""} optionMsg="Select Institute" options={["Kesharam Memorial Manakchand Public School", "KMMPS"]}
//                 className="bg-white p-3 rounded-md outline-none text-gray-700 placeholder:text-gray-400"
//               />
//               <Options label={""} optionMsg="Select Year" options={["2024", "2025"]}
//                 className="bg-white p-3 rounded-md outline-none text-gray-700 placeholder:text-gray-400"
//               />
//               {/* <button onClick={handlelogin}
//                 className="bg-gradient-to-r from-yellow-400 to-yellow-500 text-white text-xl font-semibold py-2 rounded-md shadow-md hover:opacity-90 "
//               > Set Session
//               </button> */}
//               <div className="flex justify-center">
//                 <button onClick={handlelogin}
//                   className="bg-gradient-to-r from-yellow-400 to-yellow-500 text-white text-lg font-semibold py-1 px-5 rounded-md shadow-md hover:opacity-90 transition-all duration-200"
//                 >
//                   Set Session
//                 </button>
//               </div>
//             </div>
//             {/* Footer */}
//             <p className="cursor-default text-md text-yellow-400 mt-6 text-center">
//               © Powered By{" "} <span onClick={website} className="cursor-pointer text-white">Systrans Technology Pvt. Ltd. </span>
//             </p>
//         </div>
//     </div>
//   );
// }

// export default Selection;


import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import Options from "../../Components/Page_Forms/Options";
import { getinstitute, getsession } from "../../services/api"; // ✅ added getsession

function Selection() {
  const navigate = useNavigate();

  const [institutes, setInstitutes] = useState([]);
  const [selectedInstituteId, setSelectedInstituteId] = useState("");

  // ✅ added
  const [sessions, setSessions] = useState([]);
  const [selectedSessionId, setSelectedSessionId] = useState("");

  useEffect(() => {
    async function fetchData() {
      try {
        const data = await getinstitute();
        setInstitutes(data.Table1 || []);
      } catch (error) {
        console.log("Institute API Error:", error);
      }
    }
    fetchData();
  }, []);

  // ✅ added (NO SchID used)
  useEffect(() => {
    async function fetchSessions() {
      try {
        const data = await getsession();
        setSessions(data.Table1 || []);
      } catch (error) {
        console.log("Session API Error:", error);
      }
    }
    fetchSessions();
  }, []);

  const handlelogin = () => {
    if (!selectedInstituteId || !selectedSessionId) {
      alert("Please select institute and session");
      return;
    }

    localStorage.setItem("InstituteID", selectedInstituteId);
    localStorage.setItem("SessionID", selectedSessionId);

    navigate("/Home");
  };

  const website = () => {
    window.open("https://systranstechnology.com/", "_blank");
  };

  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-cover bg-no-repeat bg-[url(/background_poster2.png)]">
      <div className="w-full mx-3 md:w-1/2 rounded-4xl bg-gradient-to-b from-[#E46343] via-[#CC3015] to-[#772109] p-8 flex flex-col justify-center">

        <h2 className="text-4xl font-bold text-white mb-6 text-center md:text-left">
          Set Session
        </h2>

        <div className="flex flex-col gap-4">

          {/* ✅ unchanged institute dropdown */}
          <Options 
            label=""
            optionMsg="Select Institute"
            options={institutes.map((item) => item.Name)} 
            onChange={(e) => { 
              const selectedName = e.target.value; 
              const selectedObj = institutes.find(ins => ins.Name === selectedName);
              
              setSelectedInstituteId(selectedObj?.Id || "");
              localStorage.setItem("InstituteName", selectedObj?.Name || "");
            }}
          />

          {/* ✅ Session dropdown (dynamic) */}
          <Options
            label=""
            optionMsg="Select Year"
            options={sessions.map(item => item.Session)}
            onChange={(e) => {
              const obj = sessions.find(s => s.Session === e.target.value);
              setSelectedSessionId(obj?.Id || "");
              localStorage.setItem("SessionName", obj?.Session || "");
            }}
            className="bg-white p-3 rounded-md outline-none text-gray-700"
          />

          <div className="flex justify-center">
            <button
              onClick={handlelogin}
              className="bg-gradient-to-r from-yellow-400 to-yellow-500 text-white text-lg font-semibold py-1 px-5 rounded-md shadow-md hover:opacity-90 transition-all duration-200"
            >
              Set Session
            </button>
          </div>
        </div>

        <p className="cursor-default text-md text-yellow-400 mt-6 text-center">
          © Powered By{" "}
          <span onClick={website} className="cursor-pointer text-white">
            Systrans Technology Pvt. Ltd.
          </span>
        </p>
      </div>
    </div>
  );
}

export default Selection;




// import React, { useEffect, useState } from "react";
// import { useNavigate } from "react-router-dom";
// import Options from "../../Components/Page_Forms/Options";
// import { getinstitute } from "../../services/api";  // <-- import API

// function Selection() {
//   const navigate = useNavigate();

//   const [institutes, setInstitutes] = useState([]);
//   const [selectedInstituteId, setSelectedInstituteId] = useState("");

//   // 🔹 Fetch Institute List on Page Load
//   // useEffect(() => {
//   //   async function fetchData() {
//   //     try {
//   //       const data = await getinstitute();
//   //       // API returns { Table: [...] }
//   //       setInstitutes(data.Table || []);
//   //     } catch (error) {
//   //       console.log("Institute API Error:", error);
//   //     }
//   //   }
//   //   fetchData();
//   // }, []);

//   useEffect(() => {
//   async function fetchData() {
//     try {
//       const data = await getinstitute();

//       // ✅ Institute list is now in Table1
//       setInstitutes(data.Table1 || []);
//     } catch (error) {
//       console.log("Institute API Error:", error);
//     }
//   }
//   fetchData();
// }, []);


//   const handlelogin = () => {
//     if (!selectedInstituteId) {
//       alert("Please select an institute");
//       return;
//     }

//     localStorage.setItem("InstituteID", selectedInstituteId); // ✅ Save ID
//     navigate("/Home");
//   };

//   const website = () => {
//     window.open("https://systranstechnology.com/", "_blank");
//   };

//   return (
//     <div className="min-h-screen w-full flex items-center justify-center bg-cover bg-no-repeat bg-[url(/background_poster2.png)]">
//       <div className="w-full mx-3 md:w-1/2 rounded-4xl bg-gradient-to-b from-[#E46343] via-[#CC3015] to-[#772109] p-8 flex flex-col justify-center">
//         <div className="flex items-center gap-3 mb-6">
//           <img
//             src="/Systrans_Logo.jpeg"
//             alt="School Logo"
//             className="h-15 w-15 object-cover rounded-full border-2 border-white flex-shrink-0"
//           />
//           <h1 className="cursor-default text-2xl font-[600] text-white">
//             SysTrans
//           </h1>
//         </div>

//         <h2 className="text-4xl font-bold text-white mb-6 text-center md:text-left">
//           Set Session
//         </h2>

//         <div className="flex flex-col gap-4">
//           {/* 🔹 Institute Options from API */}
//           {/* <Options
//             label=""
//             optionMsg="Select Institute"
//             options={institutes.map((item) => item.Name)} // <-- Dynamic
//             onChange={(e) => setSelectedInstituteId(e.target.value)}
//             className="bg-white p-3 rounded-md outline-none text-gray-700 placeholder:text-gray-400"
//           /> */}

//           <Options 
//             label="" optionMsg="Select Institute" options={institutes.map((item) => item.Name)} 
//             onChange={(e) => { 
//               const selectedName = e.target.value; 
//               const selectedObj = institutes.find( 
//                 (ins) => ins.Name === selectedName
//               );
              
//               setSelectedInstituteId(selectedObj?.Id || "");
//               localStorage.setItem("InstituteName", selectedObj?.Name || "");
//             }}
//           />


//           {/* <Options
//             label=""
//             optionMsg="Select Institute"
//             options={institutes.map((item) => item.Name)}
//             // onChange={(e) => {
//             //   const selectedName = e.target.value;
//             //   const selectedObj = institutes.find(ins => ins.Name === selectedName);
//             //   setSelectedInstituteId(selectedObj?.Id || "");
//             // }}
//             onChange={(e) => {
//               const selectedName = e.target.value;
//               const selectedObj = institutes.find(
//                 (ins) => ins.Name === selectedName
//               );

//               setSelectedInstituteId(selectedObj?.Id || "");

//               // ✅ Save name also
//               localStorage.setItem("InstituteName", selectedObj?.Name || "");
//             }}
//             className="bg-white p-3 rounded-md outline-none text-gray-700 placeholder:text-gray-400"
//           /> */}

//           {/* Year Options (static for now, dynamic later) */}
//           <Options
//             label="" optionMsg="Select Year" options={["2024", "2025"]}
//             className="bg-white p-3 rounded-md outline-none text-gray-700 placeholder:text-gray-400"
//           />

//           <div className="flex justify-center">
//             <button
//               onClick={handlelogin}
//               className="bg-gradient-to-r from-yellow-400 to-yellow-500 text-white text-lg font-semibold py-1 px-5 rounded-md shadow-md hover:opacity-90 transition-all duration-200"
//             >
//               Set Session
//             </button>
//           </div>
//         </div>

//         <p className="cursor-default text-md text-yellow-400 mt-6 text-center">
//           © Powered By{" "}
//           <span onClick={website} className="cursor-pointer text-white">
//             Systrans Technology Pvt. Ltd.
//           </span>
//         </p>
//       </div>
//     </div>
//   );
// }

// export default Selection;
