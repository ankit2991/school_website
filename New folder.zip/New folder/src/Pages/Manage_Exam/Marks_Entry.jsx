import React, { useEffect, useState } from 'react'
import Heading from '../../Components/Page_Forms/Heading'
import CheckBox from '../../Components/Page_Forms/CheckBox'
import Options from '../../Components/Page_Forms/Options'
import FormInput from '../../Components/Page_Forms/FormInput'
import Buttons from '../../Components/Page_Forms/Buttons'
import { useNavigate } from 'react-router-dom'
import RadioButton from '../../Components/Page_Forms/RadioButton'
import { getclass, getexam, getsubexam, getsubject } from '../../services/api';

function Marks_Entry() {
    const navigate = useNavigate()
    const [agree, setAgree] = useState(false)
    const [agree2, setAgree2] = useState(false)
    const [selected, setSelected] = useState("option1");

    const [classList, setClassList] = useState([]);
    const instId = localStorage.getItem("InstituteID");  // ✅ Get dynamic ID
    // useEffect(() => {
    //     if (!instId) return;
        
    //     async function fetchClasses() {
    //         try {
    //             const res = await getclass(instId);  // ✅ Pass selected Institute ID
    //             setClassList(res.Table || []);
    //         } catch (error) {
    //             console.log("Class API Error:", error);
    //         }
    //     }
        
    //     fetchClasses();
    // }, []);

    useEffect(() => {
        //   const instId = localStorage.getItem("InstituteID");
        if (!instId) return;
        
        async function fetchClasses() {
            try {
                const res = await getclass(instId);
                // ✅ check API success
                if (res?.Table?.[0]?.ResultCode === "R100") {
                    setClassList(res.Table1 || []);
                } else {
                    setClassList([]);
                }
            } catch (error) {
                console.log("Class API Error:", error);
                setClassList([]);
            }
        }
        
        fetchClasses();
    }, []);


    const [examlist, setExamlist] = useState([]);
    useEffect(() => {
        if(!instId) return;
        
        async function fetchExam() {
            try{
                const res = await getexam(instId);
                setExamlist(res.Table || []);
                console.log("For examlist:", instId)
            } catch (error) {
                console.log("Exam API Error:", error);
            }
        }

        fetchExam();
    }, []);

    const [subexamlist, setSubexamlist] = useState([]);
    useEffect (() => {
        if(!instId) return;

        async function fetchSubexam() {
            try{
                const res = await getsubexam(instId);
                setSubexamlist(res.Table || []);
                console.log("For Subexam:", instId);
            } catch (error) {
                console.log("Sub Exam API Error:", error);
            }
            
        }

        fetchSubexam();
    },[])

    const [selectedClassId, setSelectedClassId] = useState("");
    const [selectedExamId, setSelectedExamId] = useState("");
    const [selectedSubExamId, setSelectedSubExamId] = useState("");
    
    const [subjectList, setSubjectList] = useState([]);
    useEffect(() => {
        if (!instId || !selectedClassId || !selectedExamId || !selectedSubExamId) {
            return;
        }
        
        async function fetchSubjects() {
            try {
                const res = await getsubject(
                    instId, selectedClassId, selectedExamId, selectedSubExamId
                );
                
                setSubjectList(res.Table1 || []);
                console.log("Subject List:", res.Table1);
            } catch (error) {
                console.log("Subject API Error:", error);
            }
        }

        fetchSubjects();
    }, [selectedClassId, selectedExamId, selectedSubExamId]);


    
    return (
        <div className="w-full h-full bg-white flex flex-col px-4 py-2">
            <div className="flex justify-between items-center gap-x-4 mb-5">
                <Heading label={"Marks Entry"} style={"text-[22px] sm:text-3xl"} />
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-x-6 gap-y-3 mb-5 w-full">
                <CheckBox 
                    label={"Supplementry"} labelClass='text-[20px] sm:mt-8' checkstyle={"sm:mt-8"} 
                    name={""} checked={agree} onChange={(e) => setAgree(e.target.checked)}
                />
                
                {/* <Options label={"Class"} optionMsg="Select Class" options={classList.map(item => item.ClassName)} /> */}
                <Options 
                    label={"Class"} optionMsg="Select Class" options={classList} valueKey="Id" 
                    labelKey="ClassName" onChange={(e) => setSelectedClassId(e.target.value)} 
                />

                {/* <Options label={"Exam"} optionMsg="Select Exam" options={examlist.map(item => item.Name)} /> */}
                <Options 
                    label={"Exam"} optionMsg="Select Exam" options={examlist} valueKey="Id" 
                    labelKey="Name" onChange={(e) => setSelectedExamId(e.target.value)}
                />

                {/* <Options label={"Sub-Exam"} optionMsg="Select Sub-Exam" options={subexamlist.map(item => item.Name)} /> */}
                <Options 
                    label={"Sub-Exam"} optionMsg="Select Sub-Exam" options={subexamlist} valueKey="Id" 
                    labelKey="Name" onChange={(e) => setSelectedSubExamId(e.target.value)} 
                />

                <FormInput label={"Date"} type='date' />
                
                {/* <Options label={"Subject"} optionMsg="Select Subject" options={["Hindi", "English"]} /> */}
                <Options 
                    label={"Subject"} optionMsg="Select Subject" options={subjectList} valueKey="Id" 
                    labelKey="Name" 
                />

                <RadioButton 
                    label="Number" name="example" value="option1" checked={selected === "option1"} 
                    onChange={(e) => setSelected(e.target.value)}
                />
                <RadioButton 
                    label="Graded" name="example" value="option2" checked={selected === "option2"}
                    onChange={(e) => setSelected(e.target.value)}
                />
                <RadioButton 
                    label="Number Graded" name="example" value="option2" checked={selected === "option2"}
                    onChange={(e) => setSelected(e.target.value)}
                />

                <FormInput label={""} placeholder={"Enter Minimum Marks"} />
                <FormInput label={""} placeholder={"Enter Maximum Marks"} />
                
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-x-6 gap-y-3 mb-5 w-full">
                <CheckBox 
                    label={"Include in Grand Total"} labelClass='text-[20px] sm:mt-8' checkstyle={"sm:mt-8"} 
                    name={""} checked={agree} onChange={(e) => setAgree(e.target.checked)}
                />
                <CheckBox 
                    label={"Saved"} labelClass='text-[20px] sm:mt-8' checkstyle={"sm:mt-8"} 
                    name={""} checked={agree} onChange={(e) => setAgree(e.target.checked)}
                />
                <CheckBox 
                    label={"Import"} labelClass='text-[20px] sm:mt-8' checkstyle={"sm:mt-8"} 
                    name={""} checked={agree} onChange={(e) => setAgree(e.target.checked)}
                />
            </div>
            
            <div className="flex justify-between sm:justify-end space-x-0 sm:space-x-10 pt-2 mt-5">
                <Buttons label={"Close"}/>
                <Buttons click={() => navigate("/Marks-Entry2")} label={"Next"} />
            </div>
        </div>
    )
}

export default Marks_Entry