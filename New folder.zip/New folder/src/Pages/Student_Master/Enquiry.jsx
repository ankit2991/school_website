// import React, { useEffect, useState } from "react";
// import Heading from "../../Components/Page_Forms/Heading";
// import Buttons from "../../Components/Page_Forms/Buttons";
// import FormInput from "../../Components/Page_Forms/FormInput";
// import { useNavigate } from "react-router-dom";
// import Table from "../../Components/Page_Forms/Table";
// import Options from "../../Components/Page_Forms/Options";
// import { getclass, getEnquiry } from "../../services/api";

// function Enquiry() {
//   const navigate = useNavigate();
  
//   const columns = [
//     { header: "Enquiry No.", accessor: "enquiryNo" },
//     { header: "Name", accessor: "name" },
//     { header: "Class", accessor: "className" },
//   ];

//   const [classList, setClassList] = useState([]);
//   const [enquiryList, setEnquiryList] = useState([]);
//   const [filteredList, setFilteredList] = useState([]);
//   const [studentName, setStudentName] = useState("");
//   const [selectedClassId, setSelectedClassId] = useState("");
//   const [loading, setLoading] = useState(false);

//   // =======================
//   // FETCH CLASS LIST
//   // =======================
//   useEffect(() => {
//     const instId = localStorage.getItem("InstituteID"); 
//     if (!instId) return; 
    
//     async function fetchClasses() { 
//       try { 
//         const res = await getclass(instId); 
//         if (res?.Table?.[0]?.ResultCode === "R100") { 
//           setClassList(res.Table1 || []); 
//         } 
//       } catch (error) { 
//         console.log("Class API Error:", error); 
//       } 
//     } 
    
//     fetchClasses(); 
//   }, []); 
//   // ======================= 
//   // SEARCH ENQUIRY 
//   // ======================= 
//   const handleSearch = async () => { 
//     const instId = localStorage.getItem("InstituteID"); 
//     const sesId = localStorage.getItem("SessionID"); 
    
//     if (!selectedClassId) { 
//       alert("Please select class"); 
//       return; 
//     } 
    
//     try { 
//       setLoading(true); 
//       const res = await getEnquiry(instId, sesId, selectedClassId); 
      
//       if (res?.Table?.[0]?.ResultCode === "R100") { 
//         const selectedClass = classList.find( 
//           (c) => String(c.Id) === String(selectedClassId) 
//         ); 

//         // 🔥 map Table1 directly with Id and EnquireNo 
//         const mappedData = (res.Table1 || []).map((item) => ({ 
//           id: item.Id, 
//           enquiryNo: item.EnquireNo, 
//           name: item.Name, 
//           className: selectedClass?.ClassName || "", 
//         })); 
        
//         setEnquiryList(mappedData); 
//         setFilteredList(mappedData); 
//       } else { 
//         setEnquiryList([]); 
//         setFilteredList([]); 
//       } 
//     } catch (error) { 
//       console.log("Enquiry API Error:", error); 
//       setEnquiryList([]); 
//       setFilteredList([]); 
//     } finally { 
//       setLoading(false); 
//     } 
//   }; 
  
//   // ======================= 
//   // NAME FILTER 
//   // ======================= 
//   useEffect(() => { 
//     if (!studentName) { 
//       setFilteredList(enquiryList); 
//     } else { 
//       setFilteredList( 
//         enquiryList.filter((item) => item.name.toLowerCase().includes(studentName.toLowerCase()) ) 
//       ); 
//     } 
//   }, [studentName, enquiryList]); 
  
//   return ( 
//     <div className="w-full h-full bg-white px-4 py-2"> 
//       {/* HEADER */} 
//       <div className="flex justify-between mb-5"> 
//         <Heading label="Enquiry Master" /> 
//         <Buttons click={() => navigate("/AddEnquiry")} label="Add" /> 
//       </div> 
      
//       {/* FILTERS */} 
//       <div className="grid sm:grid-cols-2 gap-6 mb-5"> 
//         <Options 
//           label="Class" optionMsg="Select Class" options={classList} valueKey="Id" 
//           labelKey="ClassName" onChange={(e) => setSelectedClassId(e.target.value)} 
//         /> 
        
//         <FormInput 
//           label="Student Name" value={studentName} 
//           onChange={(e) => setStudentName(e.target.value)} 
//         /> 
//       </div> 
      
//       {/* SEARCH BUTTON */} 
//       <div className="flex justify-end"> 
//         <Buttons 
//           click={handleSearch} label="Search" 
//         /> 
//       </div> 
      
//       {/* TABLE */} 
//       <div className="mt-5"> 
//         {loading ? 
//           ( <div className="text-center">Loading...</div> ) : ( 
//             <Table 
//               columns={columns} data={filteredList} actions={(row) => ( 
//                 <> 
//                   {/* Mobile name */} 
//                   <div className="sm:hidden font-medium">{row.name}</div> 
                  
//                   {/* Desktop buttons */} 
//                   <Buttons 
//                     label="Edit" className="hidden sm:inline" 
//                     click={() => navigate("/AddEnquiry", { state: { eqid: row.id } })} 
//                   /> 
                  
//                   <Buttons 
//                     label="Print" className="hidden sm:inline" click={() => window.print()} 
//                   /> 
                  
//                   {/* Mobile icons */} 
//                   <button 
//                     className="sm:hidden" onClick={() => navigate("/AddEnquiry", { state: { eqid: row.id } }) } 
//                   > 
//                     ✏️
//                   </button> 
                  
//                   <button 
//                     className="sm:hidden" onClick={() => window.print()} 
//                   > 
//                     🖨️ 
//                   </button> 
//                 </> 
//               )} 
//             /> 
//           )
//         } 
//       </div> 
//     </div> 
//   ); 
// }

// export default Enquiry;

import React, { useEffect, useState } from "react";
import Heading from "../../Components/Page_Forms/Heading";
import Buttons from "../../Components/Page_Forms/Buttons";
import FormInput from "../../Components/Page_Forms/FormInput";
import { useNavigate } from "react-router-dom";
import Table from "../../Components/Page_Forms/Table";
import Options from "../../Components/Page_Forms/Options";
import Loader from "../../Components/Page_Forms/Loader";
import { getclass, getEnquiry } from "../../services/api";

function Enquiry() {
  const navigate = useNavigate();

  const columns = [
    { header: "Enquiry No.", shortHeader: "Eq. No.", accessor: "enquiryNo" },
    { header: "Name", shortHeader: "Name", accessor: "name" },
    { header: "Class", shortHeader: "Class", accessor: "className" },
  ];

  const [classList, setClassList] = useState([]);
  const [enquiryList, setEnquiryList] = useState([]);
  const [filteredList, setFilteredList] = useState([]);
  const [studentName, setStudentName] = useState("");
  const [selectedClassId, setSelectedClassId] = useState("");
  const [loading, setLoading] = useState(false);
  const [searched, setSearched] = useState(false);


  // =======================
  // FETCH CLASS LIST
  // =======================
  useEffect(() => {
    const instId = localStorage.getItem("InstituteID");
    if (!instId) return;

    async function fetchClasses() {
      try {
        setLoading(true);
        const res = await getclass(instId);
        if (res?.Table?.[0]?.ResultCode === "R100") {
          setClassList(res.Table1 || []);
        }
      } catch (error) {
        console.log("Class API Error:", error);
      } finally {
        setLoading(false); // ✅ STOP loader
      }
    }

    fetchClasses();
  }, []);

  // =======================
  // SEARCH ENQUIRY
  // =======================
  const handleSearch = async () => {
    const instId = localStorage.getItem("InstituteID");
    const sesId = localStorage.getItem("SessionID");

    if (!selectedClassId) {
      alert("Please select class");
      return;
    }

    try {
      setLoading(true);
      setSearched(true);
      const res = await getEnquiry(instId, sesId, selectedClassId);

      if (res?.Table?.[0]?.ResultCode === "R100") {
        const selectedClass = classList.find(
          (c) => String(c.Id) === String(selectedClassId)
        );

        const mappedData = (res.Table1 || []).map((item) => ({
          id: item.Id,
          enquiryNo: item.EnquireNo,
          name: item.Name,
          className: selectedClass?.ClassName || "",
        }));

        setEnquiryList(mappedData);
        setFilteredList(mappedData);
      } else {
        setEnquiryList([]);
        setFilteredList([]);
      }
    } catch (error) {
      console.log("Enquiry API Error:", error);
      setEnquiryList([]);
      setFilteredList([]);
    } finally {
      setLoading(false);
    }
  };

  // =======================
  // NAME FILTER
  // =======================
  useEffect(() => {
  const searchText = studentName?.toLowerCase() || "";

  if (!searchText) {
    setFilteredList(enquiryList);
    return;
  }

  const filtered = enquiryList.filter((item) => {
    const name = item?.name ? item.name.toLowerCase() : "";
    return name.includes(searchText);
  });

  setFilteredList(filtered);
}, [studentName, enquiryList]);

  return (
    <div className="w-full h-full bg-white px-4 py-2">
      {/* LOADER */}
      <Loader show={loading} />

      {/* HEADER */}
      <div className="flex justify-between mb-5">
        <Heading label="Enquiry Master" />
        <Buttons click={() => navigate("/AddEnquiry")} label="Add" />
      </div>

      {/* FILTERS */}
      <div className="grid sm:grid-cols-2 gap-6 mb-5">
        <Options
          label="Class"
          optionMsg="Select Class"
          options={classList}
          valueKey="Id"
          labelKey="ClassName"
          onChange={(e) => setSelectedClassId(e.target.value)}
        />

        <FormInput
          label="Student Name"
          value={studentName}
          onChange={(e) => setStudentName(e.target.value)}
        />
      </div>

      {/* SEARCH BUTTON */}
      <div className="flex justify-end">
        <Buttons click={handleSearch} label="Search" />
      </div>

      {/* TABLE */}
      {/* {searched && (<div className="mt-5">
        <Table
          columns={columns}
          data={filteredList}
          actions={(row) => (
            <>
              <div className="sm:hidden font-medium">{row.name}</div>

              <Buttons
                label="Edit"
                className="hidden sm:inline"
                click={() =>
                  navigate("/AddEnquiry", { state: { eqid: row.id } })
                }
              />

              <Buttons
                label="Print"
                className="hidden sm:inline"
                click={() => window.print()}
              />

              <button
                className="sm:hidden"
                onClick={() =>
                  navigate("/AddEnquiry", { state: { eqid: row.id } })
                }
              >
                ✏️
              </button>

              <button
                className="sm:hidden"
                onClick={() => window.print()}
              >
                🖨️
              </button>
            </>
          )}
        />
      </div> )} */}

      {searched && (
  <div className="mt-5">
    <Table
      columns={columns}
      data={filteredList}
      actions={(row) => (
        <>
          {/* Desktop buttons */}
          <Buttons
            label="Edit"
            style="hidden sm:inline"
            click={() =>
              navigate("/AddEnquiry", { state: { eqid: row.id } })
            }
          />

          <Buttons
            label="Print"
            style="hidden sm:inline"
            click={() => window.print()}
          />

          {/* Mobile icons */}
          <button
            className="sm:hidden text-lg pt-2.5"
            onClick={() =>
              navigate("/AddEnquiry", { state: { eqid: row.id } })
            }
          >
            ✏️
          </button>

          <button
            className="sm:hidden text-xl pt-2.5"
            onClick={() => window.print()}
          >
            🖨️
          </button>
        </>
      )}
    />
  </div>
)}

    </div>
  );
}

export default Enquiry;
