import React, { useEffect, useState } from "react";
import Heading from "../../Components/Page_Forms/Heading";
import Buttons from "../../Components/Page_Forms/Buttons";
import FormInput from "../../Components/Page_Forms/FormInput";
import { useNavigate } from "react-router-dom";
import Table from "../../Components/Page_Forms/Table";
import Options from "../../Components/Page_Forms/Options";
import Loader from "../../Components/Page_Forms/Loader";
import { getclass, getStudentList } from '../../services/api';

function Create_Student() {
  const navigate = useNavigate();
  const columns = [
    { header: "Student Id", shortHeader: "Stud. Id", accessor: "id" },
    { header: "Name", accessor: "name" },
    // { header: "Class", accessor: "class" },
  ];
 
  const [classList, setClassList] = useState([]);
  const [selectedClassId, setSelectedClassId] = useState("");
  const [loading, setLoading] = useState(false);
  const [studentList, setStudentList] = useState([]);
  const [filteredList, setFilteredList] = useState([]);
  const [studentName, setStudentName] = useState("");
  const [searched, setSearched] = useState(false);


 // =======================
  // FETCH CLASS LIST
  // =======================
  useEffect(() => {
    const instId = localStorage.getItem("InstituteID");
    if (!instId) return;

    async function fetchClasses() {
      try {
        setLoading(true);
        const res = await getclass(instId);
        if (res?.Table?.[0]?.ResultCode === "R100") {
          setClassList(res.Table1 || []);
        }
      } catch (error) {
        console.log("Class API Error:", error);
      } finally {
        setLoading(false); // ✅ STOP loader
      }
    }

    fetchClasses();
  }, []);

  // =======================
  // SEARCH ENQUIRY
  // =======================
 const handleSearch = async () => {
  const instId = localStorage.getItem("InstituteID");
  const sesId = localStorage.getItem("SessionID");

  if (!selectedClassId) {
    alert("Please select class");
    return;
  }

  try {
    setLoading(true);
    setSearched(true);

    const res = await getStudentList(instId, sesId, selectedClassId);

    // ✅ API returns data directly in Table
    if (Array.isArray(res?.Table)) {
      const mappedData = res.Table.map((item) => ({
        id: item.Id,
        name: item.Name,
      }));

      setStudentList(mappedData);
      setFilteredList(mappedData);
    } else {
      setStudentList([]);
      setFilteredList([]);
    }
  } catch (error) {
    console.log("Student API Error:", error);
    setStudentList([]);
    setFilteredList([]);
  } finally {
    setLoading(false);
  }
};


 


// =======================
  // NAME FILTER
  // =======================
  useEffect(() => {
  const searchText = studentName?.toLowerCase() || "";

  if (!searchText) {
    setFilteredList(studentList);
    return;
  }

  const filtered = studentList.filter((item) => {
    const name = item?.name ? item.name.toLowerCase() : "";
    return name.includes(searchText);
  });

  setFilteredList(filtered);
}, [studentName, studentList]);



  // return (
  //   <div className="w-full h-full bg-white flex flex-col px-4 py-2">
  //     {/* LOADER */}
  //     <Loader show={loading} />
  //     <div className="flex justify-between items-center gap-x-4 mb-5">
  //       <Heading label={"Student Master"} style={"text-[22px] sm:text-3xl"} />
  //       <Buttons
  //         click={() => navigate("/Create-Student")}
  //         label={"Add"}
  //         style="whitespace-nowrap h-10"
  //       />
  //     </div>

  //     <div className="grid grid-cols-1 sm:grid-cols-2  gap-6 mb-5 w-full">
  //      <Options 
  //         label="Class" optionMsg="Select Class" options={classList} valueKey="Id" 
  //         labelKey="ClassName" onChange={(e) => setSelectedClassId(e.target.value)} 
  //       /> 
  //       <FormInput label={"Student Name"} placeholder={"Enter Student Name"} />
  //     </div>
  //     <div className="flex justify-end">
  //       <Buttons click={() => navigate("/")} label={"Search"} />
  //     </div>
  //     <div className="mt-5">
  //       <Table
  //         columns={columns}
  //         data={data}
  //         actions={(row) => (
  //           <>
  //             <Buttons
  //               label={"Edit"}
  //               click={() => console.log("Edit:", row)}
  //               style="hidden sm:inline"
  //             />
  //             <Buttons
  //               label={"Print"}
  //               click={() => console.log("Print:", row)}
  //               style="hidden sm:inline"
  //             />
  //             {/* Mobile icons */}
  //             <button
  //               className="sm:hidden text-lg pt-2.5"
  //               onClick={() => console.log("Edit:", row)}
  //             >
  //               ✏️
  //             </button>
  //             <button
  //               className="sm:hidden text-xl pt-2.5"
  //               onClick={() => console.log("Print:", row)}
  //             >
  //               🖨️
  //             </button>
  //           </>
  //         )}
  //       />
  //     </div>
  //   </div>
  // );

  return (
    <div className="w-full h-full bg-white px-4 py-2">
      {/* LOADER */}
      <Loader show={loading} />

      {/* HEADER */}
      <div className="flex justify-between mb-5">
        <Heading label="Enquiry Master" />
        <Buttons click={() => navigate("/Create-Student")} label="Add" />
      </div>

      {/* FILTERS */}
      <div className="grid sm:grid-cols-2 gap-6 mb-5">
        <Options
          label="Class"
          optionMsg="Select Class"
          options={classList}
          valueKey="Id"
          labelKey="ClassName"
          onChange={(e) => setSelectedClassId(e.target.value)}
        />

        <FormInput
          label="Student Name"
          value={studentName}
          onChange={(e) => setStudentName(e.target.value)}
        />
      </div>

      {/* SEARCH BUTTON */}
      <div className="flex justify-end">
        <Buttons click={handleSearch} label="Search" />
      </div>

      {/* TABLE */}
{/* {searched && (
  <div className="mt-5">
    <Table
      columns={columns}
      data={filteredList}
      actions={(row) => (
        <>
          <div className="sm:hidden font-medium">{row.id}</div>
          <div className="sm:hidden font-medium">{row.name}</div>

          <Buttons
  label="Edit"
  className="hidden sm:inline"
  click={() =>
    navigate("/Create-Student", {
      state: {
        studId: row.id,
        classId: selectedClassId,
      },
    })
  }
/>

          <Buttons
            label="Print"
            className="hidden sm:inline"
            click={() => window.print()}
          />

          <button
            className="sm:hidden"
            onClick={() =>
              navigate("/Create-Student", { state: { eqid: row.id } })
            }
          >
            ✏️
          </button>

          <button
            className="sm:hidden"
            onClick={() => window.print()}
          >
            🖨️
          </button>
        </>
      )}
    />
  </div>
)} */}

{searched && (
  <div className="mt-5">
    <Table
      columns={columns}
      data={filteredList}
      actions={(row) => (
        <>
          {/* Desktop buttons */}
         <Buttons
  label="Edit"
  style="hidden sm:inline"
  click={() =>
    navigate("/Create-Student", {
      state: {
        studId: row.id,
        classId: selectedClassId,
      },
    })
  }
/>

<Buttons
  label="Print"
  style="hidden sm:inline"
  click={() => window.print()}
/>


          {/* Mobile icons */}
          <button
            // className="sm:hidden text-lg pt-2.5"
            className="sm:hidden text-lg"
            onClick={() =>
              navigate("/Create-Student", {
                state: {
                  studId: row.id,
                  classId: selectedClassId,
                },
              })
            }
          >
            ✏️
          </button>

          <button
            className="sm:hidden text-xl"
            onClick={() => window.print()}
          >
            🖨️
          </button>
        </>
      )}
    />
  </div>
)}


    </div>
  );
}

export default Create_Student;
