import React, { useEffect, useState } from 'react'
import Heading from '../../Components/Page_Forms/Heading'
import FormInput from '../../Components/Page_Forms/FormInput'
import Buttons from '../../Components/Page_Forms/Buttons'
import { useLocation, useNavigate } from 'react-router-dom'
import Options from '../../Components/Page_Forms/Options'
import { getSiblingDetails, getStudentList } from '../../services/api'
import Table from '../../Components/Page_Forms/Table'
import useClassList from '../../hooks/useClassList'

function Add_Sibling2() {
  const instId = localStorage.getItem("InstituteID"); 
  const userId = localStorage.getItem("UserId"); 
  const sessId = localStorage.getItem("SessionID"); 
  const location = useLocation(); 
  const editStudId = location.state?.studId || null; 
  const navigate = useNavigate();
  const [siblings, setSiblings] = useState([])
  const columns = [ 
    { header: "S.No.", shortHeader: "No", accessor: "sno", }, 
    { header: "Student", shortHeader: "Student", accessor: "StudentName", }, 
    { header: "Class", shortHeader: "Class", accessor: "ClassName", }, 
  ];

  const siblingTableData = siblings.map((s, index) => ({
  ...s,
  sno: index + 1,
}));

const { classList } = useClassList(); // 👈 only use classList

  const [selectedClassId, setSelectedClassId] = useState("");
  const [studentList, setStudentList] = useState([]);
  const [selectedStudentId, setSelectedStudentId] = useState("");

  const [errorMsg, setErrorMsg] = useState("");




  



   useEffect(() => {
  if (!editStudId || !instId || !sessId) return;

  async function fetchSiblingDetails() {
    try {
      const res = await getSiblingDetails(instId, editStudId, sessId);

      /* -------- Table (Student Details) -------- */
      const d = res?.Table?.[0];
      if (d) {
        setFormData({
          enrollno: d.EnrollmentNo || "",
          name: d.Name || "",
          fName: d.FatherName || "",
          mNane: d.MotherName || "",
          dob: apiDateToInput(d.DOB),
          joinDate: apiDateToInput(d.JoinDate),
        });
      }

      /* -------- Table1 (Sibling List) -------- */
      if (Array.isArray(res?.Table1)) {
        setSiblings(res.Table1);
      } else {
        setSiblings([]);
      }
    } catch (err) {
      console.error("Sibling Details Error:", err);
    }
  }

  fetchSiblingDetails();
}, [editStudId, instId, sessId]);


  const [formData, setFormData] = useState({
    enrollno: "",
    name:"", 
    fName: "",
    mNane: "", 
    dob: "", 
    joinDate: "",
  });

  // API → INPUT
    const apiDateToInput = (apiDate) => {
      if (!apiDate) return "";
      const timestamp = parseInt(apiDate.match(/\d+/)[0], 10);
      const d = new Date(timestamp);
      const year = d.getFullYear();
      const month = String(d.getMonth() + 1).padStart(2, "0");
      const day = String(d.getDate()).padStart(2, "0");
      return `${year}-${month}-${day}`;
    };


    useEffect(() => {
  if (!selectedClassId || !instId || !sessId) {
    setStudentList([]);
    return;
  }

  async function fetchStudents() {
    try {
      const res = await getStudentList(instId, sessId, selectedClassId);

      if (Array.isArray(res?.Table)) {
        setStudentList(res.Table);
      } else {
        setStudentList([]);
      }
    } catch (err) {
      console.error("Student List Error:", err);
      setStudentList([]);
    }
  }

  fetchStudents();
}, [selectedClassId, instId, sessId]);


const handleAddSibling = () => {
  if (!selectedClassId || !selectedStudentId) {
    setErrorMsg("Please select both class and student");
    return;
  }

  const selectedClass = classList.find(
    (c) => String(c.Id) === String(selectedClassId)
  );

  const selectedStudent = studentList.find(
    (s) => String(s.Id) === String(selectedStudentId)
  );

  if (!selectedClass || !selectedStudent) return;

  // 🔴 DUPLICATE CHECK
  const alreadyExists = siblings.some(
    (s) => String(s.StudentId) === String(selectedStudent.Id)
  );

  if (alreadyExists) {
    setErrorMsg("Student already added");
    return;
  }

  // ✅ Add sibling
  const newSibling = {
    StudentId: selectedStudent.Id,
    StudentName: selectedStudent.Name,
    ClassId: selectedClass.Id,
    ClassName: selectedClass.ClassName,
  };

  setSiblings((prev) => [...prev, newSibling]);

  // clear only error message
  setErrorMsg("");
};



  return (
    <div className="w-full min-w-sm h-full px-4 py-2 bg-white flex flex-col ">
      <div className="flex justify-between mb-5">
        <Heading label={"Add Sibling"} />
        <Buttons click={() => navigate("/")} label={"Edit"} />
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-5 w-full">
        <FormInput label={"Enrollment Number" }placeholder={"Enter Enrollment No."}  name="enrollno" value={formData.enrollno} />
        <FormInput label={"Name"} placeholder={"Enter Student Name"}  name="name" value={formData.name} />
        <FormInput label={"Father Name"} placeholder={"Enter Father Name"}  name="fName" value={formData.fName} />
        <FormInput label={"Mother Name" }placeholder={"Enter Mother Name"} name="mNane" value={formData.mNane} />
        <FormInput label={"Date Of Birth"} type="date" placeholder={"Select Date"}  name="dob" value={formData.dob} />
        <FormInput label={"Date Of Joining"} type="date" placeholder={"Select Date"}  name="joinDate" value={formData.joinDate} />
      </div>

   

      <div className="self-center p-3 bg-[#fcf8e5] border border-gray-400 shadow-lg rounded-md w-full lg:w-5xl">

  <div className="flex flex-col sm:flex-row sm:justify-between gap-6 mb-5">
    <Options
      label="Class"
      optionMsg="Select Class"
      options={classList}
      valueKey="Id"
      labelKey="ClassName"
      onChange={(e) => setSelectedClassId(e.target.value)}
    />

    <Options
      label="Student"
      optionMsg="Select Student"
      options={studentList}
      valueKey="Id"
      labelKey="Name"
      onChange={(e) => setSelectedStudentId(e.target.value)}
    />
  </div>

  {/* 🔴 Error Message */}
  {errorMsg && (
    <div className="text-red-600 text-sm mb-3 text-center font-medium">
      {errorMsg}
    </div>
  )}

  <div className="overflow-hidden rounded-lg border border-gray-300 shadow-md">
    <Table
      columns={columns}
      data={siblingTableData}
    />
  </div>

  <div className="flex justify-center mt-4">
    <Buttons label="Add" click={handleAddSibling} />
  </div>

</div>




      <div className='flex justify-between sm:justify-end py-5 space-x-10'>
        <Buttons click={() => navigate("/")} label={"Cancel"} />
        <Buttons click={() => navigate("/")} label={"Save"} />
      </div>
    </div>
  )
}

export default Add_Sibling2